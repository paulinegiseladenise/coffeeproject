package com.example.countdown

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.lifecycle.ViewModelProvider

//Tillslut lyckades jag byta vy ifrån mainactivity till mainactivity2
// (som förra filen hette countdown) genom att högerklicka på layout
// och create en ny empty activity från scratch.
// Satt hela dagen både inne och ute och tillslut gick det! lyckan! 1-0 till mig.

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: UserViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val resetBtn = findViewById<Button>(R.id.resetBtn)

        viewModel = ViewModelProvider(this)[UserViewModel::class.java]

        resetBtn.setOnClickListener () {
            val intent = Intent(this, Countdown::class.java)
            startActivity(intent)
        }
    }
}