package com.example.countdown

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlin.Result

class Countdown : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_countdown)

val toResultBtn = findViewById<Button>(R.id.toResultBtn)
        toResultBtn.setOnClickListener() {
            val intent = Intent(this, Result2::class.java)
            startActivity(intent)
        }

//försöker att lägga till en knapp för att kunna ta mig till resultactivityn

        }
    }