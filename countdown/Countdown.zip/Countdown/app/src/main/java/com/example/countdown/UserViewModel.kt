package com.example.countdown

import androidx.lifecycle.ViewModel

class UserViewModel : ViewModel(){

}